﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using dk.arok.data.conventus.Model;
using dk.arok.data.conventus;

namespace ark_projects.Test
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            ConventusAddressWrapper caw = new ConventusAddressWrapper();
            List <ConventusMedlem> l = caw.getMembersFromConventus();
            
            TextBox1.Text += "Antal Poster=" + l.Count;
            foreach (ConventusMedlem m in l)
            {
                TextBox1.Text += m.ToString();
            }

            

        }

    }
}



